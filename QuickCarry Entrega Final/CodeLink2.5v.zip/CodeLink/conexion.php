<?php
$host = "localhost";
$user = "root";
$password = "";
$db_name = "api";
$con = mysqli_connect($host, $user, $password, $db_name);
if ($con->connect_error) {
    die("Conexión fallida: " . $con->connect_error);
}
?>