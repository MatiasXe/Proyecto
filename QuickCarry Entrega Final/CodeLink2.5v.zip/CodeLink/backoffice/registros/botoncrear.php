<?php
$url = 'http://localhost/CodeLink/backoffice/registros/registrarapi.php';
$postParameters = [
    'user' => $_POST['user'],
    'pass' => $_POST['pass'],
    'roles' => $_POST['roles']
];

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => json_encode($postParameters),
    CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json'
    ),
));

$response = curl_exec($curl);

if (curl_errno($curl)) {
    $error_message = curl_error($curl);
    die('Error en la solicitud cURL: ' . $error_message);
}

curl_close($curl);

$data = json_decode($response, true);

if ($data === NULL) {
    die('Error al decodificar la respuesta JSON');
}

if ($data['resultado'] === true) {
    header("Location: http://localhost/CodeLink/backoffice/registros/registros.html");
    exit;
} else {
    echo "<h1>Algo salió mal</h1> <br>";
    echo "<h2>Vuelve a intentarlo</h2>";
}
