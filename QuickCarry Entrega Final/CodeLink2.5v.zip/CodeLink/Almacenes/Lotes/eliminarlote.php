<?php
if (!isset($_GET["id"])) {
    exit("ID no proporcionado");
}

$id = $_GET["id"];

include_once "../../conexion.php";

$con->autocommit(false);

try {

    $id = $con->real_escape_string($id);

    $eliminarid_lote = "DELETE FROM paquetes_lotes WHERE id_lote = '$id'";
    $resultado1 = $con->query($eliminarid_lote);

    if (!$resultado1) {
        throw new Exception("Error al eliminar registros de la tabla lotes: " . $con->error);
    }

    $eliminarid = "DELETE FROM lotes WHERE id = '$id'";
    $resultado2 = $con->query($eliminarid);

    if (!$resultado2) {
        throw new Exception("Error al eliminar registros de la tabla paquetes_lotes: " . $con->error);
    }

    $con->commit();

    header("Location: ./lotes.php");
    exit;
} catch (Exception $e) {
    $con->rollback();

    exit("Error: " . $e->getMessage());
} finally {
    $con->close();
}
