<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="CodeLink">
    <meta name="description" content="Personas Info">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="Imagenes/Acerca-de.ico">
    <link rel="stylesheet" href="../../Almacenes/style-almacen.css">
    <link rel="stylesheet" href="../../Almacenes/style-intermedio.css" />
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <title>Almacen</title>
</head>

<body>
    <header>
        <nav></nav>
        <ul class="navbar">
            <li><a href="../../Almacenes/Paquetes/Paquetes.php">Paquetes</a></li>
            <li><a href="../../Almacenes/Lotes/lotes.php">Lotes</a></li>
        </ul>
    </header>

    <?php
    include_once "../../conexion.php";
    $resultado = $con->query("
    SELECT 
        lotes.id, 
        lotes.Fecha, 
        lotes.Peso_total, 
        lotes.Departamento_lote,
        GROUP_CONCAT(
            CONCAT_WS(
                '..',
                almacen.QR, 
                almacen.Peso, 
                almacen.Contenido, 
                almacen.Direccion, 
                almacen.Tipo, 
                almacen.Fechaentrega
            ) 
            SEPARATOR '__'
        ) AS productos 
    FROM 
        lotes 
        INNER JOIN paquetes_lotes ON paquetes_lotes.id_lote = lotes.id 
        INNER JOIN almacen ON almacen.QR = paquetes_lotes.QR_paquete 
    WHERE 
        NOT EXISTS (
            SELECT 1 FROM conducen WHERE conducen.Matricula = almacen.QR
        ) 
        AND NOT EXISTS (
            SELECT 1 FROM transportan WHERE transportan.id = lotes.id
        ) 
        AND NOT EXISTS (
            SELECT 1 FROM llevan WHERE llevan.QR = almacen.QR
        )
    GROUP BY 
        lotes.id 
    ORDER BY 
        lotes.id;
    ");

    $ventas = [];

    if ($resultado->num_rows > 0) {
        while ($fila = $resultado->fetch_assoc()) {
            $ventas[] = (object) $fila;
        }
    }

    $con->close();
    ?>

    <div class="col-xs-12">
        <h1>Lotes</h1>
        <form method="post" action="./crearlote.php">
            <button type="submit" class="btn btn-success">Agregar lote</button>
        </form>
        <br>
        <form id="formTransporte" action="../../Camionero/lotes/seleccioncamion.php" method="post">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Fecha de ingreso</th>
                        <th>Departamento del almacen</th>
                        <th>Paquetes</th>
                        <th>Peso total</th>
                        <th>Eliminar</th>
                        <th>Seleccion transporte</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ventas as $venta) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($venta->id); ?></td>
                            <td><?php echo htmlspecialchars($venta->Fecha); ?></td>
                            <td><?php echo htmlspecialchars($venta->Departamento_lote); ?></td>
                            <td>
                                <input type="hidden" name="venta_id[]" value="<?php echo htmlspecialchars($venta->id); ?>">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>QR</th>
                                            <th>Peso</th>
                                            <th>Contenido</th>
                                            <th>Dirección</th>
                                            <th>Tipo</th>
                                            <th>Fecha de entrega</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach (explode("__", $venta->productos) as $productosConcatenados) {
                                            $producto = explode("..", $productosConcatenados);
                                        ?>
                                            <tr>
                                                <td>
                                                    <input type="hidden" name="QR[]" value="<?php echo htmlspecialchars($producto[0]); ?>">
                                                    <?php echo htmlspecialchars($producto[0]); ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($producto[1]); ?></td>
                                                <td><?php echo htmlspecialchars($producto[2]); ?></td>
                                                <td><?php echo htmlspecialchars($producto[3]); ?></td>
                                                <td><?php echo htmlspecialchars($producto[4]); ?></td>
                                                <td><?php echo htmlspecialchars($producto[5]); ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </td>
                            <td><?php echo htmlspecialchars($venta->Peso_total); ?></td>
                            <td>
                                <form action="eliminarlote.php" method="get">
                                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($venta->id); ?>">
                                    <button type="submit" class="btn btn-danger">Eliminar Lote <i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                            <td>
                                <input type="checkbox" id="seleccionar_<?php echo htmlspecialchars($venta->id); ?>" name="seleccionar[]" value="<?php echo htmlspecialchars($venta->id); ?>" />

                                <label for="seleccionar_todo<?php echo htmlspecialchars($venta->id); ?>">Seleccionar</label>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-danger" id="btnAgregarTransporte">Agregar al transporte<i class="fa fa-trash"></i></button>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Espera a que el documento esté completamente cargado

            // Obtén una referencia al botón y añade un evento click
            document.getElementById("btnAgregarTransporte").addEventListener("click", function() {
                // Obtiene todos los checkboxes con nombre "seleccionar[]"
                var checkboxes = document.querySelectorAll('input[name="seleccionar[]"]:checked');

                // Obtén los valores seleccionados en un array
                var valoresSeleccionados = [];
                checkboxes.forEach(function(checkbox) {
                    valoresSeleccionados.push(checkbox.value);
                });

                // Crea un objeto FormData y agrega los valores seleccionados
                var formData = new FormData();
                valoresSeleccionados.forEach(function(valor) {
                    formData.append("seleccionar[]", valor);
                });

                // Crea una instancia de XMLHttpRequest
                var xhr = new XMLHttpRequest();

                // Define la función de devolución de llamada cuando la solicitud se completa
                xhr.onload = function() {
                    if (xhr.status >= 200 && xhr.status < 300) {
                        // La solicitud fue exitosa
                        console.log(xhr.responseText);
                    } else {
                        // La solicitud falló
                        console.error(xhr.statusText);
                    }
                };

                // Define el tipo de solicitud, la URL y si la solicitud debe ser asíncrona
                xhr.open("POST", "selecioncamion", true);

                // Envía la solicitud con los datos del formulario
                xhr.send(formData);
            });
        });
    </script>
</body>

</html>