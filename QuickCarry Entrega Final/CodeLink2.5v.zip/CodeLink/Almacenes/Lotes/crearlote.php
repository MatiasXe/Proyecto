<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="CodeLink" />
    <meta name="description" content="Personas Info" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="stylesheet" href="../../Almacenes/style-almacen.css">
    <title>Crear lote</title>
</head>

<body>

    <?php
    session_start();

    if (!isset($_SESSION["carrito"])) $_SESSION["carrito"] = [];
    $granTotal = 0;
    ?>

    <div class="col-xs-12">
        <h1>Crear lote</h1>
        <?php
        if (isset($_GET["status"])) {
            if ($_GET["status"] === "1") {
        ?>
                <div class="alert alert-success">
                    <strong>¡Correcto!</strong> Lote realizado correctamente
                </div>
            <?php
            } else if ($_GET["status"] === "2") {
            ?>
                <div class="alert alert-info">
                    <strong>Lote cancelado</strong>
                </div>
            <?php
            } else if ($_GET["status"] === "3") {
            ?>
                <div class="alert alert-info">
                    <strong>Ok</strong> Producto quitado de la lista
                </div>
            <?php
            } else if ($_GET["status"] === "4") {
            ?>
                <div class="alert alert-warning">
                    <strong>Error:</strong> El producto que buscas no existe
                </div>
            <?php
            } else if ($_GET["status"] === "5") {
            ?>
                <div class="alert alert-danger">
                    <strong>Error: </strong>El producto está agotado
                </div>
            <?php
            } else {
            ?>
                <div class="alert alert-danger">
                    <strong>Error:</strong> Algo salió mal mientras se realizaba la venta
                </div>
        <?php
            }
        }
        ?>
        <br>

        <form method="post" action="./agregarlote.php">
            <label for="QR">Ingresar QR para agregar al lote: </label>
            <input autocomplete="off" autofocus class="form-control" name="QR" require type="text" id="QR" placeholder="Escribe el codigo">

            <br><br>
            <table class="table-table-bordered">
                <thead>
                    <tr>
                        <th>QR</th>
                        <th>Direccion</th>
                        <th>Departamento</th>
                        <th>Contenido</th>
                        <th>Peso</th>
                        <th>Fecha de Entrega</th>
                        <th>Tipo</th>
                        <th>Quitar</th>
                    </tr>
                </thead>
                <tbody>

                    <?php foreach ($_SESSION["carrito"] as $indice => $producto) {
                        $granTotal += $producto->Peso;                    ?>
                        <tr>
                            <td><?php echo $producto->QR ?></td>
                            <td><?php echo $producto->Direccion ?></td>
                            <td><?php echo $producto->Departamento ?></td>
                            <td><?php echo $producto->Contenido ?></td>
                            <td><?php echo $producto->Peso ?></td>
                            <td><?php echo $producto->Fechaentrega ?></td>
                            <td><?php echo $producto->Tipo ?></td>

                        </tr>
                    <?php } ?>

                </tbody>
            </table>
            <h3>Total: <?php echo $granTotal; ?></h3>
        </form>
        <form id="terminar" action="./terminarlote.php" method="post">
            <input name="total" type="hidden" value="<?php echo $granTotal; ?>">
            <button type="submit" class="btn btn-success" form="terminar">Terminar Lote</button>
        </form>

    </div>

</body>

</html>