<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="CodeLink">
    <meta name="description" content="Personas Info">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <title>Almacen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1,
        h2 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <?php
    include("../conexion.php");

    $user = isset($_GET['user']) ? $_GET['user'] : "Invitado";

    echo "<h1>BIENVENIDO $user</h1>";

    // Consulta para obtener el número de empleado usando el nombre de usuario
    $queryUsuario = "SELECT num_empleado FROM login WHERE usu = ?";

    // Utilizar consultas preparadas para prevenir inyecciones SQL
    $stmtUsuario = $con->prepare($queryUsuario);
    $stmtUsuario->bind_param("s", $user);
    $stmtUsuario->execute();

    // Verificar errores en la consulta
    if ($stmtUsuario->error) {
        die('Error en la consulta de usuario: ' . $stmtUsuario->error);
    }

    $resultUsuario = $stmtUsuario->get_result();

    if ($resultUsuario->num_rows > 0) {
        $rowUsuario = $resultUsuario->fetch_assoc();
        $numeroUsuario = $rowUsuario['num_empleado'];

        echo "<h2>Estos son los lotes o paquetes que hay que entregar:</h2>";

        $queryPrincipal = "SELECT 
        l.id AS ID_Lote,
        l.Fecha AS Fecha,
        l.Peso_total AS Peso_total,
        l.Departamento_lote AS Departamento_lote,
        t.Matricula AS Matricula_Transporte,
        t.Peso_soporte AS Peso_Soporte_Transporte,
        t.Transporte AS Tipo_Transporte,
        GROUP_CONCAT(a.QR) AS QR_Paquetes,
        GROUP_CONCAT(a.Peso) AS Peso_Paquetes,
        GROUP_CONCAT(a.Contenido) AS Contenido_Paquetes,
        GROUP_CONCAT(a.Direccion) AS Direccion_Paquetes,
        GROUP_CONCAT(a.Tipo) AS Tipo_Paquetes,
        GROUP_CONCAT(a.Fechaentrega) AS Fecha_Entrega_Paquetes,
        GROUP_CONCAT(a.Departamento) AS Departamento_Paquetes
    FROM 
        lotes l
    JOIN 
        paquetes_lotes pl ON l.id = pl.id_lote
    JOIN 
        almacen a ON pl.QR_paquete = a.QR
    JOIN 
        llevan lv ON a.QR = lv.QR
    JOIN 
        conducen c ON lv.Matricula = c.Matricula
    JOIN 
        transporte t ON c.Matricula = t.Matricula
    WHERE 
        c.num_empleado = ?
    GROUP BY 
        l.id";

        $stmtPrincipal = $con->prepare($queryPrincipal);
        $stmtPrincipal->bind_param("i", $numeroUsuario);
        $stmtPrincipal->execute();
        $ventas = [];

        if ($stmtPrincipal->error) {
            die('Error en la consulta principal: ' . $stmtPrincipal->error);
        }

        $resultPrincipal = $stmtPrincipal->get_result();

        if ($resultPrincipal->num_rows > 0) {
            while ($fila = $resultPrincipal->fetch_assoc()) {
                $ventas[] = (object) $fila;
            }
        }
    } else {
        echo "<p>Nombre de usuario no válido</p>";
    }
    ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha de ingreso</th>
                <th>Departamento del almacen</th>
                <th>Paquetes</th>
                <th>Peso total</th>
                <th>Transporte</th>
                <th>Matricula</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($ventas as $venta) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($venta->ID_Lote); ?></td>
                    <td><?php echo htmlspecialchars($venta->Fecha); ?></td>
                    <td><?php echo htmlspecialchars($venta->Departamento_lote); ?></td>
                    <td>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>QR</th>
                                    <th>Peso</th>
                                    <th>Contenido</th>
                                    <th>Dirección</th>
                                    <th>Tipo</th>
                                    <th>Fecha de entrega</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $paquetesQR = explode(",", $venta->QR_Paquetes);
                                $paquetesPeso = explode(",", $venta->Peso_Paquetes);
                                $paquetesContenido = explode(",", $venta->Contenido_Paquetes);
                                $paquetesDireccion = explode(",", $venta->Direccion_Paquetes);
                                $paquetesTipo = explode(",", $venta->Tipo_Paquetes);
                                $paquetesFechaEntrega = explode(",", $venta->Fecha_Entrega_Paquetes);
                                $paquetesDepartamento = explode(",", $venta->Departamento_Paquetes);

                                for ($i = 0; $i < count($paquetesQR); $i++) {
                                ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($paquetesQR[$i]); ?></td>
                                        <td><?php echo htmlspecialchars($paquetesPeso[$i]); ?></td>
                                        <td><?php echo htmlspecialchars($paquetesContenido[$i]); ?></td>
                                        <td><?php echo htmlspecialchars($paquetesDireccion[$i]); ?></td>
                                        <td><?php echo htmlspecialchars($paquetesTipo[$i]); ?></td>
                                        <td><?php echo htmlspecialchars($paquetesFechaEntrega[$i]); ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </td>
                    <td><?php echo htmlspecialchars($venta->Peso_total); ?></td>
                    <td><?php echo htmlspecialchars($venta->Tipo_Transporte); ?></td>
                    <td><?php echo htmlspecialchars($venta->Matricula_Transporte); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>

</html>
