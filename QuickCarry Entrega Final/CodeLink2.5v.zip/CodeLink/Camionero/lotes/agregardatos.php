<?php
session_start();

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include_once "../../conexion.php";

    $QRs = $_POST['QR'];
    $transporte = $_POST['transporte'];
    $camionero = $_POST['camionero'];
    $matricula = $_POST['matricula'];
    $id = $_POST['id'];

    // Prepare and execute statement to get num_empleado
    $stmtextra = $con->prepare("SELECT num_empleado FROM login WHERE usu=?");
    $stmtextra->bind_param("s", $camionero);
    $stmtextra->execute();
    $stmtextra->store_result();

    if ($stmtextra->num_rows > 0) {
        $stmtextra->bind_result($num_empleado);
        $stmtextra->fetch();
        $stmtextra->close();

        // Check if the entry already exists in 'conducen' table
        $stmtextra2 = $con->prepare("SELECT * FROM conducen WHERE num_empleado = ? AND Matricula = ?");
        $stmtextra2->bind_param("is", $num_empleado, $matricula);
        $stmtextra2->execute();
        $stmtextra2->store_result();
        
        if ($stmtextra2->num_rows < 1) {
            // If the entry does not exist, insert into 'conducen' table
            $stmt = $con->prepare("INSERT INTO conducen (num_empleado, Matricula) VALUES (?, ?)");
            $stmt->bind_param("is", $num_empleado, $matricula);

            if ($stmt->execute()) {
                $response['resultado'] = true;

                if ($transporte == "Camion") {
                    // Insert into 'transportan' table
                    $stmt2 = $con->prepare("INSERT INTO transportan (id, Matricula, fecha) VALUES (?, ?, NOW())");
                    $stmt2->bind_param("ss", $id, $matricula);

                    if ($stmt2->execute()) {
                        $con->commit();
                    } else {
                        $con->rollback();
                        $response['resultado'] = false;
                        $response['error'] = "Error al insertar en la tabla 'transportan': " . $stmt2->error;
                    }

                    $stmt2->close();
                } else {
                    // Insert into 'llevan' table for each QR
                    foreach ($QRs as $QR) {
                        $stmt3 = $con->prepare("INSERT INTO llevan (QR, Matricula, fecha) VALUES (?, ?, NOW())");
                        $stmt3->bind_param("ss", $QR, $matricula);

                        if (!$stmt3->execute()) {
                            $response['resultado'] = false;
                            $response['error'] = "Error al insertar en la tabla 'llevan': " . $stmt3->error;
                        }
                    }
                }
            } else {
                $response['resultado'] = false;
                $response['error'] = "Error al insertar en la tabla 'conducen': " . $stmt->error;
            }

            $stmt->close();
        } else {
            // Entry already exists in 'conducen' table
            $response['resultado'] = false;
            $response['error'] = "La entrada ya existe en la tabla 'conducen'.";
        }
    } else {
        $response['resultado'] = false;
        $response['error'] = "No se encontró el número de empleado para el camionero proporcionado.";
    }
} else {
    $response['resultado'] = false;
    $response['error'] = "Método de solicitud no válido.";
}

header("Location: ../../Almacenes/lotes/lotes.php");
$con->close();
exit;
?>
