<?php
include_once "../../conexion.php";

if (isset($_GET['transporte'])) {
    $transporte = $_GET['transporte'];

    $query = $con->prepare("SELECT Matricula FROM transporte WHERE Transporte = ?");
    $query->bind_param("s", $transporte);
    $query->execute();
    $result = $query->get_result();

    $matriculas = [];
    while ($row = $result->fetch_assoc()) {
        $matriculas[] = $row['Matricula'];
    }

    echo json_encode($matriculas);
} else {

    echo json_encode([]);
}

$con->close();
?>
