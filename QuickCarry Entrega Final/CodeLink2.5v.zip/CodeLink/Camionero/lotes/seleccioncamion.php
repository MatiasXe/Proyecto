<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="CodeLink">
    <meta name="description" content="Personas Info">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="Imagenes/Acerca-de.ico">
    <link rel="stylesheet" href="../../Almacenes/style-almacen.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <title>Seleccion</title>
</head>

<body>
    <h1>Listo para llevar el lote o el paquete</h1>

    <div class="col-xs-12">
        <br>
        <form method="post" action="agregardatos.php" id="miFormulario" onsubmit="return validarFormulario();">>
            <table class="table-table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Fecha de ingreso</th>
                        <th>Departamento del almacen</th>
                        <th>Paquetes</th>
                        <th>Peso total</th>
                    </tr>
                </thead>
                <?php
                session_start();

                if ($_SERVER["REQUEST_METHOD"] === "POST") {
                    // Verifica si se han enviado los valores de los checkboxes
                    if (!isset($_POST["seleccionar"])) {
                        exit("Valores de checkbox no proporcionados");
                    }

                    // Include your connection file
                    include_once "../../conexion.php";

                    // Obtén los valores de los checkboxes
                    $seleccionados = $_POST["seleccionar"];

                    foreach ($seleccionados as $valor) {
                        $id = intval($valor);

                        $query = $con->prepare("
                SELECT 
                    lotes.id, 
                    lotes.Fecha, 
                    lotes.Peso_total, 
                    lotes.Departamento_lote,
                    GROUP_CONCAT(
                        almacen.QR, 
                        '..', 
                        almacen.Peso, 
                        '..', 
                        almacen.Contenido, 
                        '..', 
                        almacen.Direccion, 
                        '..', 
                        almacen.Tipo, 
                        '..', 
                        almacen.Fechaentrega 
                        SEPARATOR '__'
                    ) AS productos
                FROM 
                    lotes 
                    INNER JOIN paquetes_lotes ON paquetes_lotes.id_lote = lotes.id 
                    INNER JOIN almacen ON almacen.QR = paquetes_lotes.QR_paquete 
                WHERE 
                    lotes.id = ?
                GROUP BY 
                    lotes.id 
                ORDER BY 
                    lotes.id;
            ");

                        $query->bind_param("i", $id);
                        $query->execute();
                        $resultado = $query->get_result();

                        if ($resultado->num_rows > 0) {
                            while ($row = $resultado->fetch_assoc()) {
                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['Fecha']; ?></td>
                                    <td><?php echo $row['Departamento_lote']; ?></td>
                                    <td>
                                        <table class="table table-bordered">
                                            <tr>
                                                <th>QR</th>
                                                <th>Peso</th>
                                                <th>Contenido</th>
                                                <th>Direccion</th>
                                                <th>Tipo</th>
                                                <th>Fecha de Entrega</th>
                                            </tr>
                                            <?php foreach (explode("__", $row['productos']) as $productosConcatenados) {
                                                $producto = explode("..", $productosConcatenados);
                                            ?>
                                                <tr>
                                                    <td>
                                                        <input type="hidden" name="QR[]" value="<?php echo $producto[0] ?>" i>
                                                        <?php echo $producto[0]; ?>
                                                    </td>
                                                    <td><?php echo $producto[1]; ?></td>
                                                    <td><?php echo $producto[2]; ?></td>
                                                    <td><?php echo $producto[3]; ?></td>
                                                    <td><?php echo $producto[4]; ?></td>
                                                    <td><?php echo $producto[5]; ?></td>
                                                </tr>
                                            <?php } ?>
                                        </table>
                                    </td>
                                    <td><?php echo $row['Peso_total']; ?></td>
                                </tr>
                    <?php }
                        } else {
                            echo "No se encontraron resultados.";
                        }
                    }
                    ?>
            </table>
            <div>
                <input type="radio" class="transporte" name="transporte" value="Camioneta" checked />
                <label for="camioneta">Camioneta</label>
            </div>

            <div>
                <input type="radio" class="transporte" name="transporte" value="Camion" />
                <label for="camion">Camion</label>
                <?php
                    if (!empty($seleccionados)) {
                        $id = intval($seleccionados[0]);
                ?>
                    <input type="hidden" name="id" value="<?php echo $id; ?>" id="id">
                <?php } ?>

            </div>

            <select id="matricula" name="matricula"></select>

            <h2> <label>¿Qué camionero lo llevará?</label></h2>
            <br>
            <select id="camionero" name="camionero">
                <?php
                    $camioneroQuery = "SELECT usu FROM login WHERE role = 'camionero'";
                    $resultCamionero = $con->query($camioneroQuery);
                    while ($fila = $resultCamionero->fetch_assoc()) {
                        echo "<option value=" . $fila['usu'] . ">" . $fila['usu'] . "</option>";
                    }
                ?>
            </select>
            <input type="submit" class="boton" name="enviar" value="Enviar datos">
        </form>
    </div>
<?php

                    // Cierra la conexión
                    $con->close();
                }
?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var matriculaDropdown = document.getElementById("matricula");

        function loadMatriculas() {
            var transporte = document.querySelector('input[name="transporte"]:checked');

            // Clear existing options
            matriculaDropdown.innerHTML = "";

            // Fetch matriculas based on selected transporte
            fetch("http://localhost/CodeLink/Camionero/lotes/matricula.php?transporte=" + transporte.value)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log("Matrículas obtenidas:", data);

                    // Check if data is empty
                    if (data.length === 0) {
                        console.error("No se encontraron matrículas para el transporte seleccionado.");
                    } else {
                        // Populate the matricula dropdown
                        data.forEach(matricula => {
                            var option = document.createElement("option");
                            option.value = matricula;
                            option.text = matricula;
                            matriculaDropdown.add(option);
                        });
                    }
                })
                .catch(error => console.error("Error fetching matriculas:", error));
        }

        // Llamada inicial al cargar la página
        loadMatriculas();

        var checkboxes = document.querySelectorAll('.transporte');

        checkboxes.forEach(function(checkbox) {
            checkbox.addEventListener('change', loadMatriculas);
        });

    });
</script>
</body>

</html>