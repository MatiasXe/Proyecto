<?php
session_start();

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include_once "../../conexion.php";

    $QRs = isset($_POST['QR']) ? $_POST['QR'] : array();
    $transporte = isset($_POST['transporte']) ? $_POST['transporte'] : '';
    $camionero = isset($_POST['camionero']) ? $_POST['camionero'] : '';
    $matricula = isset($_POST['matricula']) ? $_POST['matricula'] : '';

    // Verifica que los datos obligatorios estén presentes
    if (empty($QRs) || empty($transporte) || empty($camionero) || empty($id) || empty($matricula)) {
        $response['resultado'] = false;
        $response['error'] = "Faltan datos obligatorios.";
    } else {
        // Prepare and execute statement to get num_empleado
        $stmtextra = $con->prepare("SELECT num_empleado FROM login WHERE usu=?");
        $stmtextra->bind_param("s", $camionero);
        $stmtextra->execute();
        $stmtextra->store_result();

        if ($stmtextra->num_rows > 0) {
            $stmtextra->bind_result($num_empleado);
            $stmtextra->fetch();
            $stmtextra->close();

            // Prepare and execute statement to insert into 'conducen' table
            $stmt = $con->prepare("INSERT INTO conducen (num_empleado, Matricula) VALUES (?, ?)");
            $stmt->bind_param("ss", $num_empleado, $matricula);

            if ($stmt->execute()) {
                $response['resultado'] = true;

                // Prepare and execute statement to insert into 'llevan' table for each QR
                foreach ($QRs as $QR) {
                    $stmt3 = $con->prepare("INSERT INTO llevan (QR, Matricula, fecha) VALUES (?, ?, NOW())");
                    $stmt3->bind_param("ss", $QR, $matricula);

                    if (!$stmt3->execute()) {
                        $response['resultado'] = false;
                        $response['error'] = "Error al insertar en la tabla 'llevan': " . $stmt3->error;
                    }

                    $stmt3->close();
                }
            } else {
                $response['resultado'] = false;
                $response['error'] = "Error al insertar en la tabla 'conducen': " . $stmt->error;
            }

            $stmt->close();
        } else {
            $response['resultado'] = false;
            $response['error'] = "No se encontró el número de empleado para el camionero proporcionado.";
        }
    }
} else {
    $response['resultado'] = false;
    $response['error'] = "Método de solicitud no válido.";
}

// Utiliza json_encode para enviar una respuesta JSON en lugar de redirigir con header
echo json_encode($response);

// No cierres la conexión si planeas realizar más operaciones después de esta parte del código
// $con->close();
exit;
