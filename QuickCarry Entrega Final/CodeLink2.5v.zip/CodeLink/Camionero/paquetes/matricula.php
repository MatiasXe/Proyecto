<?php
include_once "../../conexion.php";

// Verificar si se proporciona el parámetro de transporte
if (isset($_GET['transporte'])) {
    $transporte = $_GET['transporte'];

    // Utiliza una declaración preparada para prevenir inyección SQL
    $query = $con->prepare("SELECT Matricula FROM transporte WHERE Transporte = ?");
    $query->bind_param("s", $transporte);
    $query->execute();
    $result = $query->get_result();

    // Almacena las matrículas en un array
    $matriculas = [];
    while ($row = $result->fetch_assoc()) {
        $matriculas[] = $row['Matricula'];
    }

    // Devuelve las matrículas como un array JSON
    echo json_encode($matriculas);
} else {
    // Si no se proporciona el parámetro de transporte, devuelve un array vacío
    echo json_encode([]);
}

// Cierra la conexión
$con->close();
?>
