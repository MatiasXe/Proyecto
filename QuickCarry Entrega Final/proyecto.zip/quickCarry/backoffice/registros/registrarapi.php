<?php
session_start();
header("Content-Type: application/json");
include('../../conexion.php');

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $json = file_get_contents('php://input');
    $datos = json_decode($json);

    if ($datos && isset($datos->user) && isset($datos->pass) && isset($datos->roles)) {
        $username = mysqli_real_escape_string($con, $datos->user);
        $password = mysqli_real_escape_string($con, $datos->pass);
        $roles = mysqli_real_escape_string($con, $datos->roles);

        $sql = "INSERT INTO login (usu, contra, role) VALUES ('$username', '$password', '$roles')";
        $result = mysqli_query($con, $sql);

        if ($result) {
            if (mysqli_affected_rows($con) == 1) {
                $response['resultado'] = true;
            } else {
                $response['resultado'] = false;
            }
        } else {
            $response['resultado'] = false;
            $response['error'] = mysqli_error($con);
        }
    } else {
        $response['resultado'] = false;
    }
} else {
    $response['resultado'] = false;
}

// Devolver la respuesta en formato JSON
echo json_encode($response);

// Cerrar la conexión a la base de datos
mysqli_close($con);
?>
