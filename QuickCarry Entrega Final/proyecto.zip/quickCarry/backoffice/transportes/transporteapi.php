<?php
session_start();
header("Content-Type: application/json");
include('../../conexion.php');

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $json = file_get_contents('php://input');
    $datos = json_decode($json);

    if ($datos && isset($datos->matricula) && isset($datos->peso) && isset($datos->transporte)) {
        $matricula = mysqli_real_escape_string($con, $datos->matricula);
        $peso = mysqli_real_escape_string($con, $datos->peso);
        $transporte = mysqli_real_escape_string($con, $datos->transporte);

        $sql = "INSERT INTO transporte (Matricula, Peso_soporte, transporte) VALUES ('$matricula', '$peso', '$transporte')";
        $result = mysqli_query($con, $sql);

        if ($result) {
            if (mysqli_affected_rows($con) == 1) {
                $response['resultado'] = true;
            } else {
                $response['resultado'] = false;
            }
        } else {
            $response['resultado'] = false;
            $response['error'] = mysqli_error($con);
        }
    } else {
        $response['resultado'] = false;
    }
} else {
    $response['resultado'] = false;
}

// Devolver la respuesta en formato JSON
echo json_encode($response);

// Cerrar la conexión a la base de datos
mysqli_close($con);
?>
