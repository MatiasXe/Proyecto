<?php
include("../../conexion.php");

$matricula = mysqli_real_escape_string($con, $_POST['matricula']); // Agregar escapado para prevenir SQL injection

$verificar = "SELECT * FROM transporte WHERE Matricula='$matricula'";
$verifico = mysqli_query($con, $verificar);

if (mysqli_num_rows($verifico) > 0) {
    ?>
    <script>
        alert("Esta matricula ya existe, agregue una distinta");
        window.location.href = 'http://localhost/quickCarry/backoffice/transportes/a%C3%B1adirtransporte.html';
    </script>
    <?php
    
} else {
    $url = 'http://localhost/quickCarry/backoffice/transportes/transporteapi.php';
    $postParameters = [
        'matricula' => $_POST['matricula'],
        'peso' => $_POST['peso'],
        'transporte' => $_POST['transporte']
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($postParameters),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    ]);

    $response = curl_exec($curl);

    if (curl_errno($curl)) {
        $error_message = curl_error($curl);
        die('Error en la solicitud cURL: ' . $error_message);
    }

    curl_close($curl);
    var_dump($response);

    $data = json_decode($response, true);

    if ($data === NULL) {
        die('Error al decodificar la respuesta JSON');
    }

    if ($data['resultado'] === true) {
        header("Location: http://localhost/quickCarry/backoffice/transportes/a%C3%B1adirtransporte.html");
        exit;
    } else {
        echo "<h1>Algo salió mal</h1> <br>";
        echo "<h2>Vuelve a intentarlo</h2>";
    }
}
?>
