<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="CodeLink">
    <meta name="description" content="Personas Info">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <title>Almacen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1,
        h2 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <?php
    include("../conexion.php");

    $user = isset($_GET['user']) ? $_GET['user'] : "Invitado";

    echo "<h1>BIENVENIDO $user</h1>";

    // Consulta para obtener el número de empleado usando el nombre de usuario
    $queryUsuario = "SELECT num_empleado FROM login WHERE usu = ?";

    // Utilizar consultas preparadas para prevenir inyecciones SQL
    $stmtUsuario = $con->prepare($queryUsuario);
    $stmtUsuario->bind_param("s", $user);
    $stmtUsuario->execute();

    // Verificar errores en la consulta
    if ($stmtUsuario->error) {
        die('Error en la consulta de usuario: ' . $stmtUsuario->error);
    }

    $resultUsuario = $stmtUsuario->get_result();

    if ($resultUsuario->num_rows > 0) {
        $rowUsuario = $resultUsuario->fetch_assoc();
        $numeroUsuario = $rowUsuario['num_empleado'];

        echo "<h2>Estos son los lotes o paquetes que hay que entregar:</h2>";

        $queryPrincipal = "SELECT 
            login.num_empleado AS Num_empleado,
            llevan.QR AS QR_Paquete,
            lotes.id AS ID_Lote,
            lotes.Fecha AS Fecha,
            lotes.Departamento_lote AS Departamento_lote,
            GROUP_CONCAT(paquetes_lotes.QR_paquete SEPARATOR '__') AS productos,
            lotes.Peso_total AS Peso_total,
            transporte.Transporte AS Tipo_Transporte,
            transporte.Matricula AS Matricula
            FROM 
            login
            JOIN conducen ON login.num_empleado = conducen.num_empleado
            JOIN llevan ON conducen.Matricula = llevan.Matricula
            JOIN transporte ON conducen.Matricula = transporte.Matricula
            LEFT JOIN paquetes_lotes ON llevan.QR = paquetes_lotes.QR_paquete
            LEFT JOIN lotes ON paquetes_lotes.id_lote = lotes.id
            WHERE login.num_empleado = ?
            GROUP BY 
            lotes.id, lotes.Fecha, lotes.Departamento_lote, lotes.Peso_total";

        $stmtPrincipal = $con->prepare($queryPrincipal);
        $stmtPrincipal->bind_param("i", $numeroUsuario);
        $stmtPrincipal->execute();
        $ventas = [];

        if ($stmtPrincipal->error) {
            die('Error en la consulta principal: ' . $stmtPrincipal->error);
        }

        $resultPrincipal = $stmtPrincipal->get_result();

        if ($resultPrincipal->num_rows > 0) {
            while ($fila = $resultPrincipal->fetch_assoc()) {
                $ventas[] = (object) $fila;
            }
        }
    } else {
        echo "Nombre de usuario no válido";
    }
    ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha de ingreso</th>
                <th>Departamento del almacen</th>
                <th>Paquetes</th>
                <th>Peso total</th>
                <th>Transporte</th>
                <th>Matricula</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($ventas as $venta) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($venta->ID_Lote); ?></td>
                    <td><?php echo htmlspecialchars($venta->Fecha); ?></td>
                    <td><?php echo htmlspecialchars($venta->Departamento_lote); ?></td>
                    <td>
                        <?php
                        $productos = explode("__", $venta->productos);
                        foreach ($productos as $productoConcatenado) {
                            $producto = explode("..", $productoConcatenado);
                        ?>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>QR</th>
                                        <th>Peso</th>
                                        <th>Contenido</th>
                                        <th>Dirección</th>
                                        <th>Tipo</th>
                                        <th>Fecha de entrega</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (explode("..", $productoConcatenado) as $productosConcatenados) {
                                        $productoDetalle = explode("..", $productosConcatenados);
                                    ?>
                                        <tr>
                                            <td>
                                                <input type="hidden" name="QR[]" value="<?php echo htmlspecialchars($productoDetalle[0]); ?>">
                                                <?php echo htmlspecialchars($productoDetalle[0]); ?>
                                            </td>
                                            <?php
                                            $qrValue = htmlspecialchars($productoDetalle[0]);

                                            // Consulta preparada para obtener detalles del contenido del paquete
                                            $queryContenido = "SELECT * FROM almacen WHERE QR = ?";
                                            $stmtContenido = $con->prepare($queryContenido);
                                            $stmtContenido->bind_param("i", $qrValue);
                                            $stmtContenido->execute();

                                            // Verificar errores en la consulta de contenido
                                            if ($stmtContenido->error) {
                                                die('Error en la consulta de contenido: ' . $stmtContenido->error);
                                            }

                                            $resultContenido = $stmtContenido->get_result();

                                            // Mostrar detalles del contenido en la tabla
                                            if ($resultContenido->num_rows > 0) {
                                                while ($contenido = $resultContenido->fetch_assoc()) {
                                            ?>
                                                    <td><?php echo htmlspecialchars($contenido['Peso']); ?></td>
                                                    <td><?php echo htmlspecialchars($contenido['Contenido']); ?></td>
                                                    <td><?php echo htmlspecialchars($contenido['Direccion']); ?></td>
                                                    <td><?php echo htmlspecialchars($contenido['Tipo']); ?></td>
                                                    <td><?php echo htmlspecialchars($contenido['Fechaentrega']); ?></td>
                                            <?php
                                                }
                                            } else {
                                                // Puedes mostrar un mensaje en caso de que no haya detalles disponibles para el paquete
                                                echo "<td colspan='5'>No hay detalles disponibles</td>";
                                            }
                                            ?>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        <?php } ?>
                    </td>
                    <td><?php echo htmlspecialchars($venta->Peso_total); ?></td>
                    <td><?php echo htmlspecialchars($venta->Tipo_Transporte); ?></td>
                    <td><?php echo htmlspecialchars($venta->Matricula); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>

</html>
