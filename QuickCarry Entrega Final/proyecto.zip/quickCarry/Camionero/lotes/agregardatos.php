<?php
session_start();

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include_once "../../conexion.php";

    $QRs = $_POST['QR'];
    $transporte = $_POST['transporte'];
    $camionero = $_POST['camionero'];
    $id = $_POST['id'];
    $matricula = $_POST['matricula'];

    // Prepare and execute statement to get num_empleado
    $stmtextra = $con->prepare("SELECT num_empleado FROM login WHERE usu=?");
    $stmtextra->bind_param("s", $camionero);
    $stmtextra->execute();
    $stmtextra->store_result();

    if ($stmtextra->num_rows > 0) {
        $stmtextra->bind_result($num_empleado);
        $stmtextra->fetch();
        $stmtextra->close();

        // Prepare and execute statement to insert into 'conducen' table
        $stmt = $con->prepare("INSERT INTO conducen (num_empleado, Matricula) VALUES (?, ?)");
        $stmt->bind_param("ss", $num_empleado, $matricula);

        if ($stmt->execute()) {
            $response['resultado'] = true;

            if ($transporte == "Camion") {
                $stmt2 = $con->prepare("INSERT INTO transportan (id, Matricula,fecha) VALUES (?, ?,NOW())");

                // Vincular parámetros
                $stmt2->bind_param("ss", $id, $matricula);

                $con->begin_transaction();

                $con->close();
            } else {
                // Prepare and execute statement to insert into 'llevan' table for each QR
                foreach ($QRs as $QR) {
                    $stmt3 = $con->prepare("INSERT INTO llevan (QR, Matricula,fecha) VALUES (?, ?,NOW())");
                    $stmt3->bind_param("ss", $QR, $matricula);

                    if (!$stmt3->execute()) {
                        $response['resultado'] = false;
                        $response['error'] = "Error al insertar en la tabla 'llevan': " . $stmt3->error;
                    }

                    $stmt3->close();
                }
            }
        } else {
            $response['resultado'] = false;
            $response['error'] = "Error al insertar en la tabla 'conducen': " . $stmt->error;
        }

        $stmt->close();
    } else {
        $response['resultado'] = false;
        $response['error'] = "No se encontró el número de empleado para el camionero proporcionado.";
    }
} else {
    $response['resultado'] = false;
    $response['error'] = "Método de solicitud no válido.";
}

header("Location: ../../Almacenes/lotes/lotes.php");
$con->close();
exit;
