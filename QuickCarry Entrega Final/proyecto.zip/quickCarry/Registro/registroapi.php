<?php
session_start();
header("Content-Type: application/json");

include('../conexion.php');

$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $json = file_get_contents('php://input');
    $datos = json_decode($json);

    if ($datos && isset($datos->user, $datos->pass, $datos->email, $datos->direccion)) {
        $user = $con->real_escape_string($datos->user);
        $pass = $con->real_escape_string($datos->pass);
        $email = $con->real_escape_string($datos->email);
        $direccion = $con->real_escape_string($datos->direccion);
        
        $stmt = $con->prepare("INSERT INTO cliente (usu, direccion, contra, gmail) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user, $direccion, $pass, $email);

        if ($stmt->execute()) {
            $response['resultado'] = true;
        } else {
            $response['resultado'] = false;
            $response['error'] = $stmt->error; 
        }

        $stmt->close();
    } else {
        $response['resultado'] = false;
        $response['error'] = "Datos incompletos";
    }
} else {
    $response['resultado'] = false;
    $response['error'] = "Método de solicitud incorrecto";
}

echo json_encode($response);

$con->close();
