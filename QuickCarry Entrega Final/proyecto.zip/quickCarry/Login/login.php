<?php
session_start();
header("Content-Type: application/json");

include('../conexion.php');

$response = array();

// Check for request method
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $json = file_get_contents('php://input');
    $datos = json_decode($json);

    if ($datos && isset($datos->user) && isset($datos->pass)) {
        $username = mysqli_real_escape_string($con, $datos->user);
        $password = mysqli_real_escape_string($con, $datos->pass);

        // Consulta en la tabla "login" para buscar empleados
        $queryEmpleado = "SELECT * FROM login WHERE usu='$username' AND contra='$password'";
        $resultadoEmpleado = $con->query($queryEmpleado);
        
        // Consulta en la tabla "cliente" para buscar clientes
        $queryCliente = "SELECT * FROM cliente WHERE usu='$username' AND contra='$password'";
        $resultadoCliente = $con->query($queryCliente);

        if ($resultadoEmpleado->num_rows > 0 || $resultadoCliente->num_rows > 0) {
            $response['resultado'] = true;
            $response['mensaje'] = "Usuario y contraseña encontrados";
        } else {
            $response['resultado'] = false;
            $response['mensaje'] = "Usuario o contraseña incorrectos";
        }
    } else {
        $response['resultado'] = false;
        $response['mensaje'] = "Datos de usuario y contraseña no proporcionados correctamente";
    }
} else {
    $response['resultado'] = false;
    $response['mensaje'] = "Método de solicitud incorrecto. Se espera una petición POST";
}

// Return the JSON response
echo json_encode($response);

// Close the database connection
mysqli_close($con);
?>
