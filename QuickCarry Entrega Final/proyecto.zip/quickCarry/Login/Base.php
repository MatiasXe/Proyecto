<?php
include("../conexion.php");

$url = 'http://localhost/quickCarry/Login/login.php';

if (isset($_POST['user']) && isset($_POST['pass'])) {
    $postParameters = [
        'user' => $_POST['user'],
        'pass' => $_POST['pass']
    ];

    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($postParameters),
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
        ),
    ));

    $response = curl_exec($curl);

    if (curl_errno($curl)) {
        $error_message = curl_error($curl);
        die('Error en la solicitud cURL: ' . $error_message);
    }

    curl_close($curl);

    $data = json_decode($response, true);

    if ($data === NULL) {
        die('Error al decodificar la respuesta JSON');
    }

    if ($data['resultado'] === true) {
        $user = $postParameters['user'];
        $pass = $postParameters['pass'];

        $sqlEmpleado = "SELECT role FROM login WHERE usu='$user' AND contra='$pass'";
        $resultadoEmpleado = $con->query($sqlEmpleado);

        $sqlCliente = "SELECT * FROM cliente WHERE usu='$user' AND contra='$pass'";
        $resultadoCliente = $con->query($sqlCliente);

        if ($resultadoEmpleado->num_rows > 0) {
            $row = mysqli_fetch_assoc($resultadoEmpleado);
            $role = $row['role'];

            switch ($role) {
                case 'almacenero':
                    header("Location: http://localhost/quickCarry/Almacenes/Paquetes/Paquetes.php");
                    break;
                    case 'camionero':
                        header("Location: http://localhost/quickCarry/Camionero/camionero.php?user=$user");
                        break;
                        exit;
            }
        } elseif ($resultadoCliente->num_rows > 0) {
            header("Location: http://localhost/quickCarry/cliente.html");
            exit;
        }

        mysqli_close($con);
    } else {
        header("Location: http://localhost/quickCarry/Login/login.html");
        echo "<script>alert('La contraseña o el usuario son incorrectos, vuelve a intentarlo');</script>";
    }
} else {
    echo "Campos 'user' y 'pass' no proporcionados correctamente en la solicitud POST.";
}
