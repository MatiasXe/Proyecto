<?php
session_start();

if (!isset($_POST["total"])) {
    exit;
}

$total = $_POST["total"];
include_once "../../conexion.php"; 
$Fecha = date("Y-m-d H:i:s");
$Peso_total = $total; 

$primerQR = $_SESSION["carrito"][0]->QR;
$sql_departamento = "SELECT Departamento FROM almacen WHERE QR = ?";
$stmt_departamento = $con->prepare($sql_departamento);
$stmt_departamento->bind_param("i", $primerQR);
$stmt_departamento->execute();
$stmt_departamento->bind_result($Departamento);
$stmt_departamento->fetch();
$stmt_departamento->close();

// Insertar en la tabla 'lotes'
$sql_insert_lote = "INSERT INTO lotes (Fecha, Peso_total, Departamento_lote) VALUES (?, ?, ?)";
$stmt_insert_lote = $con->prepare($sql_insert_lote);
$stmt_insert_lote->bind_param("sds", $Fecha, $Peso_total, $Departamento);
$stmt_insert_lote->execute();
$idLote = $con->insert_id;
$stmt_insert_lote->close();

// Insertar datos en la tabla 'paquetes_lotes'
$sql_insert_paquete = "INSERT INTO paquetes_lotes (id_lote, QR_paquete) VALUES (?, ?)";
$stmt_insert_paquete = $con->prepare($sql_insert_paquete);

foreach ($_SESSION["carrito"] as $producto) {
    $QR = $producto->QR;
    $stmt_insert_paquete->bind_param("ii", $idLote, $QR);
    $stmt_insert_paquete->execute();
}

// Cerrar la conexión
$stmt_insert_paquete->close();
$con->close();

unset($_SESSION["carrito"]);
$_SESSION["carrito"] = [];
header("Location: ./lotes.php?status=1");
?>
