<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="CodeLink">
    <meta name="description" content="Personas Info">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="Imagenes/Acerca-de.ico">
    <link rel="stylesheet" href="../../Almacenes/style-almacen.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <title>Almacen</title>
</head>
<?php
if (!isset($_POST["QR"])) {
    return;
}

$QR = $_POST["QR"];
include_once "../../conexion.php";

$sentencia = $con->prepare("SELECT * FROM almacen WHERE QR = ? LIMIT 1;");
$sentencia->bind_param("i", $QR);
$sentencia->execute();
$sentencia->store_result();

if ($sentencia->num_rows == 0) {
    $sentencia->close();
    $con->close();
    header("Location: ./crearlote.php?status=4");
    exit;
}

$sentencia->bind_result($QR, $Peso, $Contenido, $Direccion, $Tipo, $Fechaentrega, $Departamento);
$sentencia->fetch();

if ($Peso < 1) {
    $sentencia->close();
    $con->close();
    header("Location: ./crearlote.php?status=5");
    exit;
}

session_start();
$indice = false;
for ($i = 0; $i < count($_SESSION["carrito"]); $i++) {
    if ($_SESSION["carrito"][$i]->QR === $QR) {
        $indice = $i;
        break;
    }
}

if ($indice === false) {
    $producto = new stdClass();
    $producto->QR = $QR;
    $producto->Direccion = $Direccion;
    $producto->Contenido = $Contenido;
    $producto->Peso = $Peso;
    $producto->Fechaentrega = $Fechaentrega;
    $producto->Tipo = $Tipo;
    $producto->Departamento = $Departamento;
    $_SESSION["carrito"][] = $producto;
}

// Aquí es donde se actualizan las tablas lotes y almacen según la lógica de tu aplicación.
// Puedes implementar la lógica de actualización aquí.

$sentencia->close();
$con->close();
header("Location: ./crearlote.php");
