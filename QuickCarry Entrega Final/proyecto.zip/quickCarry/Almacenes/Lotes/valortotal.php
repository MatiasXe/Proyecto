<?php

include_once "../../conexion.php";

$resultado = $con->query("
    SELECT 
        SUM(lotes.Peso_total) AS totalPeso
    FROM 
        lotes 
        INNER JOIN paquetes_lotes ON paquetes_lotes.id_lote = lotes.id 
        INNER JOIN almacen ON almacen.QR = paquetes_lotes.QR_paquete 
    WHERE 
        NOT EXISTS (
            SELECT 1 FROM conducen WHERE conducen.Matricula = almacen.QR
        ) 
        AND NOT EXISTS (
            SELECT 1 FROM transportan WHERE transportan.id = lotes.id
        ) 
        AND NOT EXISTS (
            SELECT 1 FROM llevan WHERE llevan.QR = almacen.QR
        )
");

$totalPeso = $resultado->fetch_assoc()['totalPeso'];

$con->close();

// Return the totalPeso as JSON
echo json_encode(['totalPeso' => $totalPeso]);
?>
