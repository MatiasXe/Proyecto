<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="CodeLink">
    <meta name="description" content="Personas Info">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="Imagenes/Acerca-de.ico">
    <link rel="stylesheet" href="../../Almacenes/style-almacen.css">
    <link rel="stylesheet" href="../../Almacenes/style-intermedio.css" />
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <title>Almacen</title>
</head>

<body>
    <header>
        <nav>
            <ul class="navbar">
                <li><a href="../../Almacenes/Paquetes/Paquetes.php">Paquetes</a></li>

                <li><a href="../../Almacenes/Lotes/lotes.php">Lotes</a></li>
            </ul>
        </nav>
    </header>

    <div style="text-align:center;">
        <h1>Bienvenido a Paquetes</h1>

        <?php
        $mysqli = new mysqli("localhost", "root", "", "api");
        $inst = $mysqli->query("SELECT *
        FROM almacen
        WHERE QR NOT IN (
            SELECT QR_paquete
            FROM paquetes_lotes
        );
        ");
        ?>
        <div id="container">
            <center>
                <table>
                    <thead>
                        <tr>
                            <th>QR</th>
                            <th>Peso</th>
                            <th>Contenido</th>
                            <th>Direccion de entrega</th>
                            <th>Departamento del almacen</th>
                            <th>Tipo</th>
                            <th>Fecha de entrega</th>
                            <th>Enviar a la camioneta</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($inst->fetch_all(MYSQLI_ASSOC) as $fila) {
                            echo '<tr>
                            <td>' . $fila['QR'] . '</td>
                            <td>' . $fila['Peso'] . '</td>
                            <td>' . $fila['Contenido'] . '</td>
                            <td>' . $fila['Direccion'] . '</td>
                            <td>' . $fila['Departamento'] . '</td>
                            <td>' . $fila['Tipo'] . '</td>
                            <td>' . $fila['Fechaentrega'] . '</td>
                            <td>
                                <form action="../../Camionero/seleccioncamion.php" method="get">
                                    <input type="hidden" name="QR" value="QR' . $fila['QR'] . '">
                                    <button type="submit" class="btn btn-danger">Seleccionar <i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>';
                        } ?></tbody>
                </table>

        </div>
        <a href="http://localhost/quickCarry/Almacenes/Paquetes/eliminar.php"><input type="button" value="Eliminar" class="boton"></a>


        <h2 style="text-align:center;">Agregar datos a almacen</h2>
        <form action="../../Almacenes/Paquetes/botonagregar.php" method="POST" onsubmit="return validation()">

            <label for="QR">QR</label>
            <input type="text" autocomplete="off" id="QR" name="QR">
            <br>
            <label for="peso">Peso</label>
            <input type="text" autocomplete="off" id="peso" name="peso">
            <br>
            <label for="contenido">Contenido</label>
            <input type="text" autocomplete="off" id="contenido" name="contenido">
            <br>
            <label for="direccion">Direccion de entrega</label>
            <input autocomplete="off" type="text" id="direccion" name="direccion">
            <br>
            <label for="departamento">Departamento del almacen:</label>
            <select id="departamento" name="departamento">
                <option value="artigas">Artigas</option>
                <option value="canelones">Canelones</option>
                <option value="cerro_largo">Cerro Largo</option>
                <option value="colonia">Colonia</option>
                <option value="durazno">Durazno</option>
                <option value="flores">Flores</option>
                <option value="florida">Florida</option>
                <option value="lavalleja">Lavalleja</option>
                <option value="maldonado">Maldonado</option>
                <option value="montevideo">Montevideo</option>
                <option value="paysandu">Paysandú</option>
                <option value="rio_negro">Río Negro</option>
                <option value="rivera">Rivera</option>
                <option value="rocha">Rocha</option>
                <option value="salto">Salto</option>
                <option value="san_jose">San José</option>
                <option value="soriano">Soriano</option>
                <option value="tacuarembo">Tacuarembó</option>
                <option value="treinta_y_tres">Treinta y Tres</option>
            </select>
            <br>
            <label for="tipo">Tipo</label>
            <select name="tipo" id="tipo">
                <option value="Fragil">Fragil</option>
                <option value="No fragil">No fragil</option>
            </select>
            <br>
            <label for="fecha">Fecha de entrega</label>
            <input type="text" id="fecha" autocomplete="off" name="fecha">
            <br>
            <input type="submit" id="boton" value="Añadir">
        </form>
        </center>
    </div>
    <script>
        function validation() {
            var QR = document.forms[0].QR.value;
            var peso = document.forms[0].peso.value;
            var contenido = document.forms[0].contenido.value;
            var fecha = document.forms[0].contenido.value;
            if (QR.length === 0 && peso.length === 0 && contenido.length === 0 && fecha.length === 0) {
                alert("Todos los campos están vacíos");
                return false;
            } else {
                if (QR.length === 0) {
                    alert("El campo QR está vacío");
                    return false;
                }
                if (fecha.length === 0) {
                    alert("El campo Fecha de entrega está vacío");
                    return false;
                }
                if (peso.length === 0) {
                    alert("El campo Peso está vacío");
                    return false;
                }
                if (contenido.length === 0) {
                    alert("El campo Contenido está vacío");
                    return false;
                }
            }
            return true;
        }
    </script>
</body>

</html>