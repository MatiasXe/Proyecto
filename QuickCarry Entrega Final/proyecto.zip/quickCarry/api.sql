-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-11-2023 a las 11:27:00
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `api`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `almacen`
--

CREATE TABLE `almacen` (
  `QR` int(11) NOT NULL,
  `Peso` int(200) NOT NULL,
  `Contenido` varchar(200) NOT NULL,
  `Direccion` varchar(200) NOT NULL,
  `Tipo` varchar(200) NOT NULL,
  `Fechaentrega` varchar(200) NOT NULL,
  `Departamento` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `almacen`
--

INSERT INTO `almacen` (`QR`, `Peso`, `Contenido`, `Direccion`, `Tipo`, `Fechaentrega`, `Departamento`) VALUES
(42, 13, 'cocina', 'ricaldoni 2860', 'Fragil', '17 Julno 2023', 'rio_negro'),
(43, 13, 'torta', 'ricaldoni 2860', 'No fragil', 'Noviembre 30 2023', 'artigas'),
(58, 65, 'sofa', 'ricaldoni 2860', 'No fragil', 'Diciembre 10 2023', 'artigas'),
(60, 56, 'sofa', 'ricaldoni 2860', 'No fragil', 'Diciembre 10 2023', 'cerro_largo'),
(236, 5, 'torta', 'ricaldoni', 'no fragil', 'diciembre 12 2023', 'Flores'),
(869, 34, 'sofa', 'ricaldoni 2860', 'No fragil', 'enero 23 2023', 'cerro_largo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `usu` varchar(200) NOT NULL,
  `id` int(200) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `contra` varchar(200) NOT NULL,
  `gmail` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`usu`, `id`, `direccion`, `contra`, `gmail`) VALUES
('Ale', 1, 'ricaldoni 2860', '568', 'alexiaacostamunioz@gmail.com'),
('Agus', 2, 'ricaldoni 2860', '568', 'alexiaacostamunioz@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conducen`
--

CREATE TABLE `conducen` (
  `num_empleado` int(11) NOT NULL,
  `Matricula` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `conducen`
--

INSERT INTO `conducen` (`num_empleado`, `Matricula`) VALUES
(2, 'STP4556');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `llevan`
--

CREATE TABLE `llevan` (
  `Matricula` varchar(200) NOT NULL,
  `QR` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `llevan`
--

INSERT INTO `llevan` (`Matricula`, `QR`) VALUES
('STP4556', 42);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login`
--

CREATE TABLE `login` (
  `usu` varchar(200) NOT NULL,
  `contra` varchar(200) NOT NULL,
  `role` varchar(200) NOT NULL,
  `num_empleado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `login`
--

INSERT INTO `login` (`usu`, `contra`, `role`, `num_empleado`) VALUES
('Matias', '098', 'almacenero', 1),
('Ale', '123', 'camionero', 2),
('Agus', '456', 'camionero', 3),
('Jorgue', '789', 'almacenero', 4),
('malena', '456', 'almacenero', 5),
('Thiago', '765', 'almacenero', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lotes`
--

CREATE TABLE `lotes` (
  `id` int NOT NULL,
  `Fecha` varchar(200) NOT NULL,
  `Peso_total` varchar(200) NOT NULL,
  `Departamento_lote` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `lotes`
--

INSERT INTO `lotes` (`id`, `Fecha`, `Peso_total`, `Departamento_lote`) VALUES
(2, '2023-11-10 16:44:20', '13', 'rio_negro'),
(5, '2023-11-14 00:46:13', '78', 'artigas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paquetes_lotes`
--

CREATE TABLE `paquetes_lotes` (
  `id_lote` int(200) NOT NULL,
  `QR_paquete` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `paquetes_lotes`
--

INSERT INTO `paquetes_lotes` (`id_lote`, `QR_paquete`) VALUES
(2, 42),
(5, 43),
(5, 58);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transportan`
--

CREATE TABLE `transportan` (
  `id` int(200) NOT NULL,
  `Matricula` varchar(200) NOT NULL,
  `fecha` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transporte`
--

CREATE TABLE `transporte` (
  `Matricula` varchar(200) NOT NULL,
  `Peso_soporte` int(200) NOT NULL,
  `Transporte` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `transporte`
--

INSERT INTO `transporte` (`Matricula`, `Peso_soporte`, `Transporte`) VALUES
('STP4556', 56, 'Camioneta'),
('STP4567', 1000, 'Camion'),
('STP4568', 70, 'Camioneta'),
('STP4569', 200, 'Camion'),
('STP4577', 100, 'Camioneta'),
('STP4587', 100, 'Camioneta');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `almacen`
--
ALTER TABLE `almacen`
  ADD PRIMARY KEY (`QR`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `llevan`
--
ALTER TABLE `llevan`
  ADD KEY `llevan_ibfk_1` (`QR`);

--
-- Indices de la tabla `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`num_empleado`);

--
-- Indices de la tabla `lotes`
--
ALTER TABLE `lotes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `paquetes_lotes`
--
ALTER TABLE `paquetes_lotes`
  ADD KEY `id_lote` (`id_lote`),
  ADD KEY `QR_paquete` (`QR_paquete`);

--
-- Indices de la tabla `transportan`
--
ALTER TABLE `transportan`
  ADD KEY `transportan_ibfk_1` (`id`);

--
-- Indices de la tabla `transporte`
--
ALTER TABLE `transporte`
  ADD PRIMARY KEY (`Matricula`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `login`
--
ALTER TABLE `login`
  MODIFY `num_empleado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `lotes`
--
ALTER TABLE `lotes`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `llevan`
--
ALTER TABLE `llevan`
  ADD CONSTRAINT `llevan_ibfk_1` FOREIGN KEY (`QR`) REFERENCES `almacen` (`QR`);

--
-- Filtros para la tabla `paquetes_lotes`
--
ALTER TABLE `paquetes_lotes`
  ADD CONSTRAINT `paquetes_lotes_ibfk_1` FOREIGN KEY (`id_lote`) REFERENCES `lotes` (`id`),
  ADD CONSTRAINT `paquetes_lotes_ibfk_2` FOREIGN KEY (`QR_paquete`) REFERENCES `almacen` (`QR`);

--
-- Filtros para la tabla `transportan`
--
ALTER TABLE `transportan`
  ADD CONSTRAINT `transportan` FOREIGN KEY (`id`) REFERENCES `lotes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
